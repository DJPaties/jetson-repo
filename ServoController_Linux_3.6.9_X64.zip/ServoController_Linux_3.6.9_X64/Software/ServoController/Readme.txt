RTrobot Servo Controller X64
Version:3.6.4

1.need install libusb(libusb-dev libusb-devel)

2.copy the file "99-rtrobot-servocontroller.rules" to "/etc/udev/rules.d/"
----------------------------
sudo cp 99-rtrobot-servocontroller.rules /etc/udev/rules.d
----------------------------

3.sudo chmod 777 /dev/ttyACM0(option)
----------------------------
run "start.sh"
----------------------------
Check update http://rtrobot.org/Software
